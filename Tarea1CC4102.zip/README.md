# Tarea 1 Logaritmos

* Viene con Makefile listo
* Se usa con "./main 512 1" para 512 rectángulos con Linear Split
* Se usa con "./main 1024 2" para 1024 rectángulos con Greene Split
